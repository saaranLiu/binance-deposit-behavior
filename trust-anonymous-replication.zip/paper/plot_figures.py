"""Build paper tables and vector figures from the archived experiment outputs."""

import csv
import json
import re
import subprocess
from pathlib import Path
from statistics import mean

import pymupdf as pdf

PAPER = Path(__file__).resolve().parent
ROOT = PAPER.parent
FIGURES = PAPER / 'figures'
PHASES = ('halt', 'restart_48h', 'paper_7d')


def rgb(value):
    return tuple(int(value[i:i + 2], 16) / 255 for i in (0, 2, 4))


INK = rgb('162E3C')
MUTED = rgb('4D626D')
BLUE = rgb('244C68')
TEAL = rgb('1B635A')
RUST = rgb('9E4836')
HISTORY = rgb('526E7C')
GRID = rgb('DCE5E8')
PALE = rgb('EBF1F3')
PALE_BLUE = rgb('E5EEF4')
PALE_TEAL = rgb('E5F1EE')
WHITE = rgb('FFFFFF')


class Figure:
    def __init__(self, width, height, fonts):
        self.document = pdf.open()
        self.page = self.document.new_page(width=width, height=height)
        self.fonts = fonts

    def text(self, x, y, value, *, size=8, font='regular', color=INK, align='left'):
        face = self.fonts[font]
        offset = {'left': 0, 'center': 0.5, 'right': 1}[align] * face.text_length(value, fontsize=size)
        writer = pdf.TextWriter(self.page.rect)
        writer.append((x - offset, y), value, font=face, fontsize=size)
        writer.write_text(self.page, color=color)

    def line(self, points, *, color=INK, width=.6, dashes=None):
        self.page.draw_polyline(points, color=color, width=width, dashes=dashes)

    def box(self, x, y, width, height, *, fill=None, border=None, stroke=.55):
        self.page.draw_rect(pdf.Rect(x, y, x + width, y + height), color=border, fill=fill, width=stroke)

    def polygon(self, points, *, fill, border=None):
        self.page.draw_polyline(points, color=border, fill=fill, closePath=True, width=.65)

    def dot(self, x, y, radius, *, fill, border=None):
        self.page.draw_circle((x, y), radius, color=border, fill=fill, width=.65)

    def arrow(self, points, *, color=INK, dashes=None):
        self.line(points, color=color, width=.8, dashes=dashes)
        x, y = points[-1]
        self.polygon([(x, y), (x - 4.4, y - 2.2), (x - 4.4, y + 2.2)], fill=color)

    def export(self, name, *, svg_title=None):
        destination = FIGURES / name
        self.document.set_metadata({'title': svg_title or name})
        self.document.subset_fonts()
        self.document.save(destination.with_suffix('.pdf'), garbage=4, deflate=True)
        width = 3840 if svg_title else round(self.page.rect.width * 300 / 72)
        scale = width / self.page.rect.width
        self.page.get_pixmap(matrix=pdf.Matrix(scale, scale), alpha=True).save(destination.with_suffix('.png'))
        if svg_title:
            height = round(self.page.rect.height * scale)
            svg = self.page.get_svg_image(text_as_path=True)
            svg = re.sub(r'(<svg\b[^>]*\bwidth=")[^"]+', rf'\g<1>{width}', svg, count=1)
            svg = re.sub(r'(<svg\b[^>]*\bheight=")[^"]+', rf'\g<1>{height}', svg, count=1)
            svg = svg.replace('>\n', f'>\n<title>{svg_title}</title>\n', 1)
            destination.with_suffix('.svg').write_text(svg)
        self.document.close()


def read_csv(path):
    with path.open(newline='') as handle:
        return list(csv.DictReader(handle))


def command(name, lines):
    return '\\newcommand{\\' + name + '}{%\n' + '\n'.join(lines) + '\n}\n'


def table_row(*cells):
    return ' & '.join(str(cell) for cell in cells) + r' \\'


def one_decimal(value):
    return f'{float(value):.1f}'


def signed(value):
    display = one_decimal(value)
    return f'${"0.0" if display == "-0.0" else display}$'


def table_source(amounts, full_shock):
    total = full_shock['total_amount']
    per_sender = full_shock['amount_per_sender']
    adjusted = full_shock['standardized_amount_per_sender']
    rows = [table_row(
        'Breach to phase-one end', '---', '---', '---',
        f'{total["event"] / 1e6:,.1f}', f'{total["historical_mean"] / 1e6:,.1f}',
        f'{per_sender["event"] / 1e3:.1f}', f'{per_sender["historical_mean"] / 1e3:.1f}',
        signed(per_sender['relative_pct']), signed(adjusted['relative_pct']),
    )]
    windows = (
        ('halt', 'Withdrawal halt'), ('restart_48h', '48 h from rollout start'),
        ('paper_7d', 'Seven days from 09:00'),
    )
    for phase, label in windows:
        result = amounts[phase, 'binance']
        rows.append(table_row(
            label, f'{result["event_active"]:,}',
            one_decimal(result['event_active_pct']), one_decimal(result['historical_mean_active_pct']),
            f'{float(result["event_total"]) / 1e6:,.1f}', f'{float(result["historical_mean_total"]) / 1e6:,.1f}',
            f'{float(result["event_amount_per_eligible"]) / 1e3:.1f}',
            f'{float(result["historical_mean_amount_per_eligible"]) / 1e3:.1f}',
            signed(result['amount_per_eligible_change_pct']),
            signed(result['standardized_amount_per_eligible_change_pct']),
        ))
    comparisons = {r['outcome']: r for r in read_csv(ROOT / 'results/comparisons.csv') if r['days'] == '7'}
    attribution = []
    for field, label in (
        ('own', "Sender's prior Binance destination"), ('b_union', 'Union of three signals'),
        ('b_match', 'Follow-up sweep (incl. Binance 151)'), ('b_static', 'Follow-up sweep (old wallets)'),
    ):
        result = comparisons[field]
        event_rate = '0' if float(result['event_pct']) == 0 else one_decimal(result['event_pct'])
        attribution.append(table_row(label, event_rate, one_decimal(result['placebo_mean_pct']), signed(result['difference_pp'])))
    adjusted = [r for r in read_csv(ROOT / 'results/adjusted.csv') if r['days'] == '7']
    checks = []
    for label, outcome, variable in (
        ('Reweighted prior-label rate', 'b', 'standardized_difference_pp'),
        ('Reweighted three-signal union', 'b_union', 'standardized_difference_pp'),
        ('Shared-sender prior-label rate', 'b', 'paired_difference_pp'),
    ):
        values = [float(r[variable]) for r in adjusted if r['outcome'] == outcome]
        assert len(values) == 7
        checks.append(table_row(label, '', '', signed(sum(values) / len(values))))
    return ('% Generated by plot_figures.py from the archived results.\n'
            + command('PrimaryResultRows', rows)
            + command('AttributionResultRows', attribution)
            + command('SensitivityResultRows', checks))


def overview(fonts):
    fig = Figure(500, 154, fonts)
    fig.text(4, 12, '(a) Incident and observation windows', font='bold', size=10)
    fig.text(495, 12, '2026 · UTC · not to scale', align='right', color=MUTED)
    milestones = (
        (47, '29 Oct · 20:05', 'Hot-wallet breach', RUST),
        (149, '29 Oct · 20:45', 'Last regular payout', BLUE),
        (249, '1 Nov · 06:00', 'Phased restart begins', TEAL),
        (347, '1 Nov · 09:00', 'Seven-day window starts', BLUE),
        (450, '1 Nov · 12:36', 'Phase one complete', TEAL),
    )
    fig.box(47, 35, 403, 9, fill=PALE_BLUE)
    fig.line([(47, 39.5), (450, 39.5)], color=HISTORY, width=.65)
    for x, time, event, color in milestones:
        fig.text(x, 29, time, size=8.8, font='bold', align='center')
        fig.dot(x, 39.5, 2.7, fill=color, border=WHITE)
        fig.text(x, 54, event, size=8.4, align='center')
    fig.line([(47, 58), (47, 61), (450, 61), (450, 58)], color=HISTORY, width=.48)
    fig.text(248.5, 70, 'Joint shock window', size=7.8, color=MUTED, align='center')

    fig.line([(4, 77), (496, 77)], color=GRID)
    fig.text(4, 88, '(b) User behavior and platform operations', font='bold', size=10)
    fig.text(495, 88, 'Ethereum · USDT and USDC', align='right', color=MUTED)
    fig.text(5, 103, 'USER BEHAVIOR', font='bold', color=TEAL, size=7.8)
    fig.text(180, 103, 'PLATFORM OPERATIONS', font='bold', color=BLUE, size=7.8)

    fig.box(5, 109, 114, 22, fill=PALE_TEAL, border=TEAL)
    fig.text(62, 123.5, 'Repeat deposit senders', size=9, font='bold', align='center')
    fig.arrow([(119, 120), (177, 120)], color=TEAL)
    fig.text(148, 115, 'Deposit', align='center', size=7.6, color=MUTED)
    fig.box(180, 109, 123, 22, fill=PALE_BLUE, border=BLUE)
    fig.text(241.5, 123.5, 'Pre-identified deposit address', size=8.8, align='center')
    fig.line([(303, 120), (332, 120)], color=BLUE, width=.8)
    fig.arrow([(332, 120), (332, 107.5), (406, 107.5)], color=HISTORY, dashes='[2 2] 0')
    fig.arrow([(332, 120), (332, 131.5), (406, 131.5)], color=BLUE)
    fig.text(365, 103, '29 Oct sweep', size=7.6, align='center', color=MUTED)
    fig.text(365, 141, '3 Nov sweep', size=7.6, align='center', color=MUTED)
    for y, wallet, fill, border in (
        (99, 'Binance 14', PALE, HISTORY), (123, 'Binance 151', PALE_BLUE, BLUE),
    ):
        fig.box(409, y, 86, 17, fill=fill, border=border)
        fig.text(452, y + 11.3, wallet, size=8.8, font='bold', align='center')

    fig.text(5, 150, 'Who returns, how much, and where?', size=8.6, font='italic', color=TEAL)
    fig.text(180, 150, 'Which deposits remain visible when sweep wallets change?', size=8.6, font='italic', color=BLUE)
    fig.export('fig_overview', svg_title='Binance incident timeline and deposit measurement')


def shock_backtest_figure(fonts, rows):
    fig = Figure(238, 148, fonts)
    fig.text(6, 12, 'Deviation from four-week forecast (%)', size=9, font='bold')
    fig.text(231, 12, '2026 · UTC', size=7.5, color=MUTED, align='right')

    def x_position(value):
        return 41 + 1.52 * (value + 100)

    fig.box(1, 103, 235, 21, fill=PALE_BLUE)
    for tick in (-100, -75, -50, -25, 0, 25):
        x = x_position(tick)
        fig.line([(x, 22), (x, 129)], color=HISTORY if tick == 0 else GRID,
                 width=.65 if tick == 0 else .45, dashes='[3 2] 0' if tick == 0 else None)
        label = f'{tick:+d}'.replace('-', '−') if tick else '0'
        fig.text(x, 141, label, size=7.9, color=MUTED, align='center')

    for y, row in zip((33, 51, 69, 87, 113), rows):
        event = row['k'] == 0
        label = f"{int(row['date'][-2:])} Oct"
        value = row['error_pct']
        x = x_position(value)
        color = BLUE if event else HISTORY
        font = 'bold' if event else 'regular'
        fig.text(6, y + 2.8, label, size=8.4, color=color, font=font)
        fig.line([(x, y), (x_position(0), y)], color=color, width=.95 if event else .6)
        if event:
            marker(fig, x, y, 'diamond', color)
        else:
            fig.dot(x, y, 2.35, fill=WHITE, border=color)
        label_offset = 7 if event or value >= 0 else -6
        fig.text(x + label_offset, y - 3.3, f'{value:+.1f}%'.replace('-', '−'), size=8.2,
                 font=font, color=color, align='left' if label_offset > 0 else 'right')
        if event:
            fig.text(231, y + 2.8, 'Breach', size=8.3, color=color, font='bold', align='right')
    fig.export('fig_shock_backtest')


def concentration(fonts):
    fig = Figure(238, 155, fonts)
    for x, label, fill, border in (
        (4, 'Top 1% of depositing addresses', BLUE, None), (142, 'All other depositors', PALE, GRID),
    ):
        fig.box(x, 5, 10, 7, fill=fill, border=border)
        fig.text(x + 14, 11, label, size=8, color=MUTED)
    volume = {(r['phase'], int(r['k'])): 100 * float(r['top_one_pct_volume_share'])
              for r in read_csv(ROOT / 'followup/amounts_and_halt.csv')
              if r['venue'] == 'binance' and r['stratum'] == r['token_group'] == 'all'}
    left, width = 44, 180
    for y, phase, label in zip((28, 65, 102), PHASES, ('Withdrawal halt', 'First 48 h after restart', 'Seven-day window')):
        fig.text(4, y, label, size=8.6, font='bold')
        shares = (volume[phase, 0], mean(volume[phase, k] for k in range(2, 9)))
        for dy, name, share in zip((4, 17), ('Event', 'History'), shares):
            length = width * share / 100
            fig.text(left - 5, y + dy + 8, name, size=8, color=MUTED, align='right',
                     font='bold' if name == 'Event' else 'regular')
            fig.box(left, y + dy, width, 10, fill=PALE, border=GRID)
            fig.box(left, y + dy, length, 10, fill=BLUE)
            fig.text(left + length - 4, y + dy + 8, f'{share:.1f}%', size=7.7, font='bold', color=WHITE, align='right')

    fig.line([(left, 136), (left + width, 136)], color=HISTORY, width=.52)
    for tick in (0, 25, 50, 75, 100):
        x = left + width * tick / 100
        fig.line([(x, 136), (x, 139)], color=HISTORY, width=.5)
        fig.text(x, 149, f'{tick}%', size=7.7, color=MUTED, align='center')
    fig.export('fig_concentration')


def marker(fig, x, y, shape, color):
    if shape == 'circle':
        fig.dot(x, y, 2, fill=WHITE, border=color)
    elif shape == 'square':
        fig.box(x - 1.7, y - 1.7, 3.4, 3.4, fill=color)
    elif shape == 'triangle':
        fig.polygon([(x, y - 2.4), (x - 2.3, y + 1.8), (x + 2.3, y + 1.8)], fill=color)
    else:
        fig.polygon([(x, y - 2.7), (x - 2.3, y), (x, y + 2.7), (x + 2.3, y)], fill=color)


def frequency_plot(fonts):
    fig = Figure(238, 151, fonts)
    fig.text(24, 12, 'Cumulative return (%)', size=9, font='bold')
    fig.text(153, 12, 'Prior deposits', size=8, font='bold')
    fig.text(233, 12, 'Day 7', size=8, font='bold', align='right')
    left, right, bottom, scale = 24, 141, 118, .94
    sample_x = (30, 66, 138)
    fig.box(148, 19, 88, bottom - 19, fill=PALE)
    for tick in (0, 25, 50, 75, 100):
        y = bottom - tick * scale
        fig.line([(left, y), (right, y)], width=.45, color=GRID)
        fig.text(left - 5, y + 2.7, str(tick), size=7.9, align='right', color=MUTED)
    fig.line([(left, bottom), (right, bottom)])
    for x, day in zip(sample_x, (1, 3, 7)):
        fig.line([(x, bottom), (x, bottom + 3)], width=.48)
        fig.text(x, 131, str(day), align='center', size=8.1, color=MUTED)
    fig.text((left + right) / 2, 145, 'Days after window start', size=8.2, align='center', color=MUTED)

    frequency = {(r['pre_deposits'], int(r['days'])): float(r['b_pct'])
                 for r in read_csv(ROOT / 'results/frequency.csv') if r['k'] == '0'}
    styles = (
        ('2-5', 'circle', HISTORY, '[3 2] 0'), ('6-20', 'square', TEAL, '[1 2] 0'),
        ('21-99', 'triangle', INK, '[5 2] 0'), ('100+', 'diamond', BLUE, None),
    )
    for group, shape, color, dash in styles:
        points = [(x, bottom - frequency[group, day] * scale) for x, day in zip(sample_x, (1, 3, 7))]
        fig.line(points, color=color, width=1, dashes=dash)
        for x, y in points:
            marker(fig, x, y, shape, color)
        x, y = points[-1]
        fig.line([(x + 3.2, y), (150, y)], color=color, width=.45)
        fig.text(153, y + 2.8, group.replace('-', '–'), color=color, size=8.3)
        fig.text(233, y + 2.8, f'{frequency[group, 7]:.1f}%', color=color, size=8.3, font='bold', align='right')
    fig.export('fig_frequency')


def load_fonts():
    names = {'regular': 'LinLibertine_R.otf', 'bold': 'LinLibertine_RB.otf', 'italic': 'LinLibertine_RI.otf'}
    return {style: pdf.Font(fontfile=subprocess.check_output(['kpsewhich', name], text=True).strip())
            for style, name in names.items()}


def main():
    rows = json.loads((ROOT / 'followup/amount_comparisons.json').read_text())
    amounts = {(row['phase'], row['venue']): row for row in rows if row['token'] == 'all'}
    identification = json.loads((ROOT / 'followup/identification_checks.json').read_text())
    fonts = load_fonts()
    overview(fonts)
    shock_backtest_figure(fonts, identification['shock_backtest'])
    concentration(fonts)
    frequency_plot(fonts)
    (PAPER / 'results_tables.tex').write_text(table_source(amounts, identification['full_shock']['binance']))


if __name__ == '__main__':
    main()
