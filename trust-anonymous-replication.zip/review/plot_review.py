"""Build the review tables and vector figures from archived results."""
import json
from pathlib import Path
from statistics import mean
import sys

from analyze_review import donor_weeks, read_summary, rolling

HERE = Path(__file__).resolve().parent
PAPER = HERE.parent / 'paper'
sys.path.insert(0, str(PAPER))
from plot_figures import BLUE, GRID, HISTORY, MUTED, PALE_BLUE, PALE_TEAL, RUST, TEAL, WHITE
from plot_figures import Figure, command, load_fonts, marker, table_row

PHASES = {'joint': 'Breach to phase-one end', 'halt': 'Withdrawal halt',
          '48h': '48 h from rollout start', '7d': 'Seven days from 09:00'}


def signed(x):
    return f'{x:+.1f}'.replace('+-', '-')


def make_tables(results):
    primary = []
    for key, title in PHASES.items():
        metrics = results['comparisons'][key]
        sample = results['absolute'][key]
        adjusted = results['reweighted'][key]['amount']
        primary.append(table_row(
            title, f'{int(sample["users"]):,}', f'{sample["usd"]/1e6:,.1f}',
            signed(metrics['participation']['event']), signed(metrics['usd']['event']),
            signed(adjusted['event']), signed(metrics['winsor']['event']),
            f'{metrics["usd"]["rank"]}/{metrics["usd"]["n"]}', f'{100*metrics["usd"]["p"]:.1f}',
        ))
    heterogeneity = []
    groups = (
        ('tier:0', r'Under \$1k'), ('tier:1', r'\$1k--10k'), ('tier:2', r'\$10k--100k'),
        ('tier:3', r'\$100k--1M'), ('tier:4', r'\$1M or more'),
        ('whale:true', r'Top 1\%'), ('whale:false', r'Other 99\%'),
        ('roundtrip:true', 'Prior wallet receipt'), ('roundtrip:false', 'No prior receipt'),
    )
    for group, label in groups:
        halt = results['heterogeneity']['halt'][group]
        week = results['heterogeneity']['7d'][group]
        if group in ('whale:true','roundtrip:true'):
            heterogeneity.append(r'\addlinespace')
        heterogeneity.append(table_row(label, f'{int(halt["n"]):,}',
            signed(halt['part']['event']), signed(halt['amount']['event']),
            signed(week['part']['event']), signed(week['amount']['event'])))
    (PAPER/'review_tables.tex').write_text(command('ReviewAmountRows',primary)
                                              +command('ReviewRobustRows',robust_rows(results))
                                              +command('ReviewGroupRows',heterogeneity))


def robust_rows(results):
    rows = []
    for metric, title, divisor in (
        ('median','Median depositor gap (\\%)',1),
        ('asinh','Mean asinh gap',1),
        ('below_own_median','Below own median (\\%)',1),
        ('within_usd','Within-sender amount gap (\\$k)',1000),
    ):
        cells=[]
        for phase in PHASES:
            row=results['comparisons'][phase][metric]
            value=row['event']/divisor
            display = f'{value:.1f}' if metric == 'below_own_median' else signed(value)
            cells.append(f'{display} ({row["rank"]}/{row["n"]})')
        rows.append(table_row(title,*cells))
    return rows


def placebos(fonts, data):
    fig = Figure(238, 168, fonts)
    fig.text(4, 11, 'Participation gap (pp)', size=9.1, font='bold')
    fig.dot(147, 8.5, 1.55, fill=WHITE, border=HISTORY)
    fig.text(152, 11, 'Placebo', size=7.7, color=MUTED)
    marker(fig, 204, 8.5, 'diamond', RUST)
    fig.text(210, 11, 'Event', size=7.7, color=RUST)

    panels = (
        ('joint', 'Joint shock', 25, 29), ('halt', 'Withdrawal halt', 140, 29),
        ('48h', '48 hours', 25, 96), ('7d', 'Seven days', 140, 96),
    )
    for phase, label, left, top in panels:
        def x(value):
            return left + 91 * (value + 105) / 232

        def y(value):
            return top + 49 * (6 - value) / 21

        fig.text(left, top - 4, label, size=8.6, font='bold')
        for tick in (-100, 0, 100):
            fig.line([(x(tick), top), (x(tick), top + 49)], color=HISTORY if tick == 0 else GRID,
                     width=.55, dashes='[2 2] 0' if tick == 0 else None)
            if top == 96:
                fig.text(x(tick), 155, str(tick).replace('-', '−'), size=7.5,
                         color=MUTED, align='center')
        for tick in (-10, 0, 5):
            fig.line([(left, y(tick)), (left + 91, y(tick))], color=HISTORY if tick == 0 else GRID,
                     width=.55, dashes='[2 2] 0' if tick == 0 else None)
            if left == 25:
                fig.text(left - 4, y(tick) + 2.5, str(tick).replace('-', '−'), size=7.5,
                         color=MUTED, align='right')
        amount, participation = (data[phase][metric] for metric in ('usd', 'participation'))
        assert amount['placebo'].keys() == participation['placebo'].keys()
        for week, gap in amount['placebo'].items():
            fig.dot(x(gap), y(participation['placebo'][week]), 1.5, fill=WHITE, border=HISTORY)
        marker(fig, x(amount['event']), y(participation['event']), 'diamond', RUST)
    fig.text(129, 165, 'Amount gap (%)', size=8, color=MUTED, align='center')
    fig.export('fig_review_placebos')


def frequency_gaps(fonts, summary):
    fig = Figure(238, 129, fonts)
    fig.text(4, 11, 'Return gap by follow-up day (pp)', size=9.1, font='bold')
    fig.text(4, 23, 'Prior', size=7.6, color=MUTED)
    fig.text(4, 32, 'deposits', size=7.6, color=MUTED)
    groups = [summary['14d', 'freq:' + group] for group in ('2-5', '6-20', '21-99', '100+')]
    row_positions = (44, 64, 84, 104)
    for y, label, weeks in zip(row_positions, ('2–5', '6–20', '21–99', '100+'), groups):
        fig.text(4, y + 2.7, label, size=8.4, font='bold')
        fig.text(53, y + 2.7, f'{int(weeks[0]["n"]):,}', size=7.7, align='right', color=MUTED)
    fig.text(53, 32, 'n', size=7.7, font='italic', align='right', color=MUTED)
    for day, left in zip((1, 3, 7, 14), (61, 105, 149, 193)):
        def x(value):
            return left + 40 * (value + 12) / 22

        fig.text(left + 20, 29, str(day), size=8.4, font='bold', align='center')
        for tick in (-10, 0, 10):
            fig.line([(x(tick), 35), (x(tick), 114)], color=HISTORY if tick == 0 else GRID,
                     width=.55, dashes='[2 2] 0' if tick == 0 else None)
            if day == 1:
                fig.text(x(tick), 125, str(tick).replace('-', '−'), size=7.4,
                         color=MUTED, align='center')
        for y, weeks in zip(row_positions, groups):
            row = rolling(weeks, '14d', lambda r: 100 * r[f'day{day}'] / r['n'])
            low, high = map(x, row['interval'])
            fig.line([(low, y), (high, y)], color=HISTORY, width=.95)
            for end in (low, high):
                fig.line([(end, y - 2.3), (end, y + 2.3)], color=HISTORY, width=.65)
            marker(fig, x(row['event']), y, 'diamond', BLUE)
    fig.export('fig_review_frequency')


def recovery_blocks(fonts, summary):
    first, full = (summary[phase, 'all'] for phase in ('7d', '14d'))
    donors = donor_weeks('14d', 0)
    assert all(first[week]['n'] == full[week]['n'] for week in (0, *donors))
    fig = Figure(238, 125, fonts)
    fig.text(4, 11, 'Recovery by week', size=9.1, font='bold')
    for left, color, label in ((129, BLUE, 'Days 1–7'), (181, TEAL, 'Days 8–14')):
        fig.box(left, 5, 7, 7, fill=color)
        fig.text(left + 10, 11, label, size=7.6, color=MUTED)

    def x(value):
        return 35 + 1.65 * value

    for tick in (0, 25, 50, 75, 100):
        for top, bottom in ((33, 57), (74, 100)):
            fig.line([(x(tick), top), (x(tick), bottom)], color=HISTORY if tick == 100 else GRID,
                     width=.55, dashes='[2 2] 0' if tick == 100 else None)
        fig.text(x(tick), 113, str(tick), size=7.5, color=MUTED, align='center')
    fig.text(118, 123, 'Share of 14-day forecast (%)', size=8, color=MUTED, align='center')
    for title, key, y in (('Addresses making a first return', 'users', 28),
                          ('Amount per eligible sender', 'usd', 69)):
        fig.text(4, y, title, size=8.5, font='bold')
        historical = [mean(row[week][key] / row[week]['n'] for week in donors) for row in (first, full)]
        event = [row[0][key] / row[0]['n'] for row in (first, full)]
        for label, cumulative, cy, colors in (
            ('Event', event, y + 11, (BLUE, TEAL)),
            ('Forecast', historical, y + 24, (PALE_BLUE, PALE_TEAL)),
        ):
            split, end = (100 * amount / historical[1] for amount in cumulative)
            fig.text(4, cy + 2.6, label, size=7.7, color=MUTED)
            fig.box(x(0), cy - 4, x(split) - x(0), 8, fill=colors[0], border=BLUE)
            fig.box(x(split), cy - 4, x(end) - x(split), 8, fill=colors[1], border=TEAL)
            if label == 'Event':
                fig.text(x(end) + 4, cy + 2.7, f'{end:.1f}', size=7.7, font='bold', color=BLUE)
    fig.document.set_metadata({'title': 'Post-reopening deposits by week'})
    fig.document.subset_fonts()
    fig.document.save(HERE/'recovery_14d.pdf',garbage=4,deflate=True)
    fig.document.close()


def main():
    results = json.loads((HERE/'review_results.json').read_text())
    summary = read_summary()
    fonts = load_fonts()
    make_tables(results)
    placebos(fonts,results['comparisons'])
    recovery_blocks(fonts,summary)
    frequency_gaps(fonts,summary)


if __name__=='__main__':
    main()
