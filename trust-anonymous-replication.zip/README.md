# Replication files for the revised Binance short paper

This directory contains the queries, aggregate exports, audit outputs, and figure generation code for the revised paper. All timestamps are UTC. Public chain transfer amounts are USDT and USDC face values.

| File | Contents |
| --- | --- |
| `review_query.sql`, `review_suffix.sql` | Executed BigQuery query for the long weekly series and address-level contrasts aggregated inside BigQuery. |
| `historical_summary.csv` | All 17,058 exported rows from 44 anchors. Contains cohort totals, group totals, robust outcomes, and covariate moments. |
| `cohort_sizes.csv`, `balance.csv`, `placebo_ranks.csv` | Generated supplementary tables. |
| `audit_query.sql`, `audit_suffix.sql`, `validation_template.sql`, `build_validation_query.py` | Event audit and address sample, plus the template and builder for checking contract deployments and late-window data coverage. |
| `audit_results.json` | Minute-by-minute initial amounts, concentration, later eligibility, label coverage, address profile, and sweep delays. |
| `review_results.json` | Forecasts, event ranks, 2.5th and 97.5th placebo percentiles, group gaps, and use of rival exchanges. |
| `recovery_14d.pdf` | First returns and deposit amount in each week after reopening, normalized to the same four-cohort fourteen-day forecast. |

Run from the replication root with Python, NumPy, PyMuPDF, and TeX Live with Linux Libertine.

```sh
python3 -B review/analyze_review.py
python3 -B review/plot_review.py
cd paper
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

## Historical forecast

The target population is the eligible address cohort, including zero-amount addresses. Anchors are Thursday 20:05 from January 1 through October 29, 2026. The query reads earlier logs as far back as November 27, 2025 for lagged outcomes and enrollment. It uses the archived seed registry and builds destination labels from the applicable pre-anchor transactions for each cohort. Registry inclusion dates and label-generation dates describe different things. Two named venue seeds in the archived registry had registry dates after January 1 but before the original August start date.

Weeks are indexed backward from October 29. The joint, halt, and 48-hour targets use the preceding four weeks. For the seven-day target the donor offsets are two through five, as the closest seven-day window can cross the target anchor. The fourteen-day offsets are three through six. A placebo eligible for a particular outcome must have an outcome window that ends before the incident and four available donors. The one-sided empirical rank is one plus the number of historical deficits at least as severe, divided by the number of eligible windows including the actual event. The share below the own median ranks in the upper tail. Rolling comparisons overlap, so these ranks describe historical extremeness. They do not act as tests based on independently assigned shocks.

For the amount-balanced estimate, we weight donors separately to the target cohort. We use cross-classified cells when each target cell has at least five donor addresses. Otherwise we match the marginal distributions by iterative proportional fitting, the entropy projection relative to the donor distribution. Adjacent categories are pooled for an unsupported marginal level. Standardized mean differences use the same pooled unweighted standard deviation before and after balancing. The closest four clean seven-day donors average 10,488 addresses, close to the event's 10,483. The annual historical panels vary from 1,457 to 11,076 in size.

## Address comparisons and validation

Amount winsorization caps the 99th percentile within each cohort and window, including zeros. The address fixed-effect coefficient is calculated with a balanced target slot and four baseline slots per eligible sender, using the same target label set. Algebraically, it equals the average target-minus-own-baseline difference. The historic placebo repeats enrollment and estimation. Self-comparisons can still be affected by eligibility selecting addresses that deposited more recently, which is why they use the historical placebo distribution. Run `analyze_review.py` for dollar and proportional effects, and for below-median shares with and without conditioning on a positive own median.

Pre-anchor amount tiers use amounts inferred in the 28-day lookback. The top percentile is ranked separately before each anchor. A round-trip address has an observed positive USDT or USDC receipt from a known Binance hot-wallet seed before the anchor. The label describes the on-chain pattern and does not establish account ownership or dependence on withdrawals. Prior contract deployments are historical observations rather than a complete account classification.

The label sample contains 28 destinations in each of nine cells formed by matching dates (2, 3–5, and 6+) and prior matched dollars (under 10,000, 10,000–100,000, and 100,000 or more). The queries draw the destinations by a fixed salted hash. Public Etherscan name tags corroborate 238 addresses. The other 14 have an accessible page without an explicit venue label. The nominal Wilson interval applies to the unweighted subset with a public venue label. The confirmation share weighted by stratum population is 94.5%; unlabeled cases remain unresolved. The reverse check identifies transfers outside the known seeds, which does not determine which entity owns their destinations.

The review archive contains aggregate validation results. To reproduce the address checks, run the saved audit query, export as `event_audit.csv`, generate the verification query with `python3 -B review/build_validation_query.py`, then export its result as `validation.csv`. Then run `python3 -B review/check_explorer_labels.py` and `python3 -B review/summarize_audit.py`. The local research workspace includes address-level check records. The review archive omits per-address case records and omits the previous pilot's precise transfer amounts.

The screening uses the archived Spellbook and incident lists, including the archived Elliptic blocklist. The FBI advisory independently reports attribution and publishes linked addresses. It is cited as incident evidence. It was not substituted for the screen used in the executed queries.

## Data provenance

- Long historical experiment: 17,058 exported BigQuery rows.
- Event and label audit: 641 exported BigQuery rows.
- Public contract and data coverage verification: 21 exported BigQuery rows. The latest indexed stablecoin transfer in the fourteen-day window is at 08:59:59 UTC on November 15.
- Sources: [Google Cloud Ethereum tables](https://docs.cloud.google.com/blockchain-analytics/docs/example-ethereum), [Dune's seed registry](https://github.com/duneanalytics/spellbook/blob/main/dbt_subprojects/hourly_spellbook/models/_sector/cex/addresses/chains/cex_evms_addresses.sql), [Etherscan explorer](https://etherscan.io/), [FBI advisory](https://www.fbi.gov/investigate/cyber/alerts/2026/north-korea-responsible-for-6-billion-binance-attack).
